

<!--<div id="Edit_crop_hide" class="profile_action absolute bottom-0 right-0 space-x-1.5 p-3 text-sm z-50 hidden lg:flex">
               <div>
                              <span class="flex items-center justify-center h-8 px-3 rounded-md bg-gray-700 bg-opacity-70 text-white space-x-1.5">
                                             <ion-icon name="create-outline" class="text-xl"></ion-icon>
                                             <span> Edit Cover Photo </span>
                                             <span></span>
                              </span>
               </div>
               
               <div class="bg-white w-56 shadow-md mx-auto p-2 mt-12 rounded-md text-gray-500 hidden text-base border border-gray-100 dark:bg-gray-900 dark:text-gray-100 dark:border-gray-700"
                    uk-drop="mode: click;pos: bottom-right;animation: uk-animation-slide-bottom-small" onclick="update_banner_image()">
                              <ul class="space-y-1">
                                             <li>
                                                            <label class="cabinet center-block">
                                                                           <figcaption><i class="fa fa-camera"></i> <span class=""> Upload Image </span></figcaption>
                                                                           <input type="file" class="item-img file center-block" name="file_photo"/>
                                                            </label>
                                             </li>
                              </ul>
               </div>


</div>-->

<label class="cabinet">
               <input type='file' class="item-img file fl-none center-block" name="banner_image" accept=".png, .jpg, .jpeg"/>
</label>

<div class="profile_action absolute bottom-0 right-0 space-x-1.5 p-3 text-sm z-50 hidden lg:flex">
               <div>
                              <a class="flex items-center justify-center h-8 px-3 rounded-md bg-gray-700 bg-opacity-70 text-white space-x-1.5" 
                                                 href="#user_banner_upload" uk-toggle>
                                             <ion-icon name="create-outline" class="text-xl"></ion-icon>
                                             <span> Edit Cover Photo </span>
                                             <span></span>
                              </a>
               </div>
               
            

</div>
<!--<div style="display:none;" id="save_crop"
class="profile_action save-btn absolute top-0 right-0 space-x-1.5 p-3 text-sm z-50 hidden lg:flex">
<button type="button" id="banner_update"
      class="label-ct" for="imageUpload">Save</button>
          <button type="button" id="cancel_crop">  <span class="btn-text"><span class="flex items-center justify-center h-8 px-3 rounded-md bg-gray-700 bg-opacity-70 text-white space-x-1.5">
      <span> Cancel</span>
  </span></span></button>
</div>-->
 



